library(testthat)
library(ypssc)

test_check("ypssc")
